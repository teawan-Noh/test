package lab.itank2;

public class Main {

	public static void main(String[] args) {
		
		Player p1 = new Player();
		
		GuessGame g1 = new GuessGame();
		g1.startGame(p1);
	}
}
