﻿package com.view;
//메세지 출력모음 클래스
public class Message
{

	public static final String MESSAGE01 = "저장하시겠습니까? ";
	public static final String MESSAGE02 = "저장되었습니다.";		
	public static final String MESSAGE03 = "검색어를 넣으세요 => ";
	public static final String MESSAGE04 = "검색완료되었습니다.";
	public static final String MESSAGE05 = "수정하시겠습니까? ";
	public static final String MESSAGE06 = "수정되었습니다.";		
	public static final String MESSAGE07 = "삭제하시겠습니까?";
	public static final String MESSAGE08 = "삭제되었습니다. ";	
	public static final String MESSAGE09 = "메뉴를 선택하세요. "	;
	
	public static final String MESSAGE10 = "검색된 리스트에서 책번호를  입력하세요.";
	public static final String MESSAGE11 = "책제목/저자/출판사 순으로 책정보를 입력하세요!(예시 : java의 정석/임미영/집 )";		
	public static final String MESSAGE12 = "취소되었습니다.";
	public static final String MESSAGE13 = "수정하고자 하는 내용을 선택하세요.";
	public static final String MESSAGE14 = "더 수정할 내용이 있습니까?";
	public static final String MESSAGE15 = "처리 중 문제가 생겼습니다.";		
	public static final String MESSAGE16 = "잘 못 선택되었습니다.";
	public static final String MESSAGE17 = "수정할 내용을 넣으세요.";	
	public static final String MESSAGE18 = "종료 하시겠습니까?";		
	public static final String MESSAGE19 = "검색된 내용이 없습니다."	;	
	public static final String MESSAGE20 = "종료되었습니다."	;	

}
