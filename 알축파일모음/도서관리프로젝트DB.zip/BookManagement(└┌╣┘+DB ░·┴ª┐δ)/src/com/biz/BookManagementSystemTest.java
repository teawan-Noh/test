﻿package com.biz;

//시작 클래스
public class BookManagementSystemTest 
{
	public static void main(String[] args) 
	{
		BookManager bm = new BookManager();
		bm.start();
	}
}
 