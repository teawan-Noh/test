﻿package com.sql;

public class Sql {
	
	//jdbc 할때 sql문만 모두 적어 놓는 클래스
	//아래 예시로 한개 써 보았음
	public static final String BOOK_INSERT = "INSERT INTO Book VALUES (?, ?, ?, ?)";
}
