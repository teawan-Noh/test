﻿package com.biz;

import java.io.IOException;

//시작 클래스
public class BookManagementSystemTest {
	public static void main(String[] args) throws IOException {
		BookManager bm = new BookManager();
		bm.start();
	}
}
