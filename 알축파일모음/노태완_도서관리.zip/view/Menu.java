﻿package com.view;
//메뉴 출력모음 클래스
public class Menu{
	
	public static final String MENU01 = "1.저장  2.검색  3.전체출력  4.종료";
	public static final String MENU02 = "1.Yes  2.No";
	public static final String MENU03 = "1.수정  2.삭제  3.주메뉴  4.종료";
	public static final String MENU04 = "1.책이름  2.저자  3.출판사";	

}
